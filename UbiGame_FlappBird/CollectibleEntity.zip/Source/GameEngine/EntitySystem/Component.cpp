#include "Component.h"
using namespace GameEngine;

Component::Component()	
{

}


Component::~Component()
{

}


void Component::Update()
{

}
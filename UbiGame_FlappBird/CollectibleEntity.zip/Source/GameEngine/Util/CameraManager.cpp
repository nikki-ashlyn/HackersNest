#include "CameraManager.h"


using namespace GameEngine;

CameraManager* CameraManager::sm_instance = nullptr;

CameraManager::CameraManager()
{

}


CameraManager::~CameraManager()
{

}